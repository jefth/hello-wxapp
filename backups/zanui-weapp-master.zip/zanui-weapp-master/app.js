
App({
  globalData: {
  },
});
