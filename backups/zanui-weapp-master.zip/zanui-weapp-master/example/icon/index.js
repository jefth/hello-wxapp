Page({
  data: {
    icons: [
      'album',
      'arrow',
      'camera',
      'certificate',
      'check',
      'checked',
      'close',
      'gift',
      'home',
      'location',
      'message',
      'send',
      'shopping-cart',
      'sign',
      'store',
      'topay',
      'tosend'
    ]
  }
});
